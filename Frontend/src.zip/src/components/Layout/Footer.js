import React from 'react'

const Footer = () => {
  return (
    <>
      <footer>
        <p className='text-center'>Food Delivery Website - 2023, All Rights Reserved &copy;</p>
      </footer>
    </>
  )
}

export default Footer
