import React from 'react'

const Footer = () => {
  return (
   <>
   <footer>
    <p className='text-center bg-warning text-dark py-3'> Food delivery website 2023-2024,All Rights Reserved</p>
   </footer>   
   </>
  )
}

export default Footer