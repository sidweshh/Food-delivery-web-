import React from 'react';

const Loader = () => {
  return <div className='Loader'></div>
    
};

export default Loader;